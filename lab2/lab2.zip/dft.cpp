#include <math.h>
#include <stdio.h>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <math.h>
#include <complex>
#include <omp.h>

#include "utils/bmp.cpp"


void compress(const std::vector<uint8_t> &values, std::vector<float> &Xreal, std::vector<float> &Ximag) {
  // values, Xreal and Ximag are values describing single color of single row of bitmap. 
  // This function will be called once per each (color, row) combination.
  size_t valuesCount = values.size();
  int accuracy = Xreal.size();
  for (int k = 0; k < accuracy; k++) {
      for (int i = 0; i < valuesCount; i++) {
          int theta = (2 * M_PI * k * i) / valuesCount;
          Xreal[k] += values[i] * cos(theta);
          Ximag[k] -= values[i] * sin(theta);
      }
  }
}

void decompress(std::vector<uint8_t> &values, const std::vector<float> &Xreal, const std::vector<float> &Ximag) {
  // values, Xreal and Ximag are values describing single color of single row of bitmap.
  // This function will be called once per each (color, row) combination.
  int accuracy = Xreal.size();
  size_t valuesCount = values.size();

  std::vector<float> rawValues(valuesCount, 0);

  for (int i = 0; i < valuesCount; i++) {
      for (int k = 0; k < accuracy; k++) {
          int theta = (2 * M_PI * k * i) / valuesCount;
          rawValues[i] += Xreal[k] * cos(theta) + Ximag[k] * sin(theta);
      }
      values[i] = rawValues[i] / valuesCount;
  }
}

void compressPar(const std::vector<uint8_t> &values, std::vector<float> &Xreal, std::vector<float> &Ximag) {
  // PUT YOUR IMPLEMENTATION HERE
}

void decompresPar(std::vector<uint8_t> &values, const std::vector<float> &Xreal, const std::vector<float> &Ximag) {
  // PUT YOUR IMPLEMENTATION HERE
}

int main() {
  BMP bmp;
  bmp.read("example.bmp");

  size_t accuracy = 16; // We are interested in values from range [8; 32]
    
  // bmp.{compress,decompress} will run provided function on every bitmap row and color.
  float compressTime = bmp.compress(compress, accuracy);
  float decompressTime = bmp.decompress(decompress);

  printf("Compress time: %.2lfs\nDecompress time: %.2lfs\nTotal: %.2lfs\n", 
    compressTime, decompressTime, compressTime + decompressTime);

  bmp.write("example_result.bmp");

  return 0;
}

